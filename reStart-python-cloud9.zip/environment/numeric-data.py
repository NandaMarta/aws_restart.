# Menampilkan jenis-jenis tipe numerik di Python
print("Python has three numeric types: int, float, and complex\n")

# Tipe data integer
myValue = 1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)) + "\n")

# Tipe data float
myValue = 3.14
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)) + "\n")

# Tipe data complex
myValue = 5j
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)) + "\n")

# Tipe data boolean True
myValue = True
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)) + "\n")

# Tipe data boolean False
myValue = False
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)) + "\n")
