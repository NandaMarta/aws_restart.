# Menanyakan kepada pengguna apakah mereka perlu mengirim paket
userReply = input("Do you need to ship a package? (Enter yes or no): ")
if userReply.lower() == "yes" or "y":
    print("We can help you ship that package!")
elif userReply.lower() == "no" or "n":
    print("Apuse Kokondao")
else:
    print("Please come back when you need to ship a package. Thank you.")

# Menanyakan kepada pengguna tentang layanan lainnya
userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy): ")
if userReply.lower() == "stamps":
    print("We have many stamp designs to choose from.")
elif userReply.lower() == "envelope":
    print("We have many envelope sizes to choose from.")
elif userReply.lower() == "copy":
    copies = input("How many copies would you like? (Enter a number): ")
    print(f"Here are {copies} copies.")
else:
    print("Thank you, please come again.")
