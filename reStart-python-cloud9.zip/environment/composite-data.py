import csv
import copy

# Definisi awal template untuk kendaraan
myVehicle = {
    "vin": "<empty>",
    "make": "<empty>",
    "model": "<empty>",
    "year": 0,
    "range": 0,
    "topSpeed": 0,
    "zeroSixty": 0.0,
    "mileage": 0
}

# Menampilkan template kendaraan
print("Template Kendaraan:")
for key, value in myVehicle.items():
    print(f"{key} : {value}")
print("\n" + "="*30 + "\n")

# Membuat list kosong untuk menyimpan data inventaris kendaraan
myInventoryList = []

# Membaca data dari file CSV
with open('car_fleet.csv') as csvFile:
    csvReader = csv.reader(csvFile, delimiter=',')
    lineCount = 0

    for row in csvReader:
        # Menampilkan nama kolom pada baris pertama
        if lineCount == 0:
            print(f'Nama Kolom: {", ".join(row)}')
            lineCount += 1
        else:
            # Menampilkan data kendaraan per baris
            print(f'vin: {row[0]}, make: {row[1]}, model: {row[2]}, year: {row[3]}, range: {row[4]}, topSpeed: {row[5]}, zeroSixty: {row[6]}, mileage: {row[7]}')

            # Membuat salinan dari template kendaraan
            currentVehicle = copy.deepcopy(myVehicle)

            # Memasukkan data dari CSV ke dalam salinan template
            currentVehicle["vin"] = row[0]
            currentVehicle["make"] = row[1]
            currentVehicle["model"] = row[2]
            currentVehicle["year"] = int(row[3])
            currentVehicle["range"] = int(row[4])
            currentVehicle["topSpeed"] = int(row[5])
            currentVehicle["zeroSixty"] = float(row[6])
            currentVehicle["mileage"] = int(row[7])

            # Menambahkan kendaraan yang telah diisi datanya ke dalam daftar inventaris
            myInventoryList.append(currentVehicle)
            lineCount += 1

    print(f'\nProcessed {lineCount} lines.\n')

# Menampilkan data inventaris kendaraan
print("Data Inventaris Kendaraan:")
for myCarProperties in myInventoryList:
    for key, value in myCarProperties.items():
        print(f"{key} : {value}")
    print("-----")
