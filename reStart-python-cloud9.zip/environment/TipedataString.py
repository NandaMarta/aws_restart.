# Data Pengimputan
myString = "This is a string."

# Menggabungkan dua string
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString  # Hasilnya adalah "waterfall"

# Mengambil input dari pengguna
name = input("What is your name? ")
color = input("What is your favorite color? ")
animal = input("What is your favorite animal? ")

# Perintah Menjalankan Data
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

# Menampilkan informasi yang diinput oleh pengguna
print(name)
print("{}, you like a {} {}!".format(name, color, animal))

# Menampilkan hasil penggabungan string
print(thirdString)
