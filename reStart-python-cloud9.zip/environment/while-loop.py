# Definisikan variabel isGuessRight dan number terlebih dahulu
isGuessRight = False  # Mengatur isGuessRight ke False agar loop dimulai
number = 7  # Angka yang benar, misalnya 7 (ubah sesuai kebutuhan)

# Looping hingga tebakan benar
while isGuessRight != True:
    # Meminta input dari pengguna untuk menebak angka antara 1 hingga 10
    guess = input("Guess a number between 1 and 10: ")
    
    # Mengecek apakah tebakan pengguna sama dengan angka yang benar
    if int(guess) == number:
        # Jika tebakan benar, tampilkan pesan kemenangan dan ubah isGuessRight menjadi True
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    else:
        # Jika tebakan salah, tampilkan pesan untuk mencoba lagi
        print("You guessed {}. Sorry, that isn’t it. Try again.".format(guess))
