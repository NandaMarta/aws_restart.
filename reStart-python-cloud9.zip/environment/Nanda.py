# Program Python sederhana tentang "cinta"

def main():
    print("❤️ Selamat Datang di Program 'Cinta' ❤️")
    print("Mari kita membuat pesan cinta yang manis !\n")
    
    # Meminta pengguna memasukkan nama mereka dan orang yang dicintai
    nama_kamu = input("Masukkan nama kamu : ")
    nama_kasih = input("Masukkan nama orang yang kamu cintai : ")

    # Pesan cinta
    pesan_cinta = f"Dear {nama_kasih},\n\n"
    pesan_cinta += f"Ketika aku mendengar namamu, hatiku terasa lebih hangat. {nama_kamu} ingin selalu berada di sampingmu,\n"
    pesan_cinta += "memberi semangat saat hari-harimu berat, dan membuatmu tersenyum setiap hari.\n\n"
    pesan_cinta += "Kamu adalah seseorang yang spesial dan tak tergantikan.\n\n"
    pesan_cinta += f"Dari yang selalu mencintaimu,\n{nama_kamu}\n"

    # Menampilkan pesan cinta
    print("\n❤️❤️❤️ Pesan Cinta ❤️❤️❤️")
    print(pesan_cinta)

# Memanggil fungsi utama
main()