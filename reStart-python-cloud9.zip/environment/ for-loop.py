print("Count to 10!")
# Dimulai dari 1 agar benar-benar menghitung dari 1 ke 10
for x in range(1, 101):
    print(x)
